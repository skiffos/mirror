This image is just a clone of the base busybox image used for testing purposes.

The Containerfile is used to build the quay.io/toolbox_tests/busybox image that
is used in the toolbox test suite.

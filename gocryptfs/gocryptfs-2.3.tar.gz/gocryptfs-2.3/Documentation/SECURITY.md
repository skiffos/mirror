This page has been moved to https://nuetzlich.net/gocryptfs/security/ .

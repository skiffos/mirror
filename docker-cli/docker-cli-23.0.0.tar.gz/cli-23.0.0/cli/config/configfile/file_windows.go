package configfile

func copyFilePermissions(src, dst string) {
	// TODO implement for Windows
}

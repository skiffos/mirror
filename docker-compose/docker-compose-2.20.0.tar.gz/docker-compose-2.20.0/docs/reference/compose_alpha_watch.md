# docker compose alpha watch

<!---MARKER_GEN_START-->
EXPERIMENTAL - Watch build context for service and rebuild/refresh containers when files are updated

### Options

| Name        | Type | Default | Description                     |
|:------------|:-----|:--------|:--------------------------------|
| `--dry-run` |      |         | Execute command in dry run mode |
| `--quiet`   |      |         | hide build output               |


<!---MARKER_GEN_END-->


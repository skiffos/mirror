# docker compose images

<!---MARKER_GEN_START-->
List images used by the created containers

### Options

| Name            | Type     | Default | Description                                 |
|:----------------|:---------|:--------|:--------------------------------------------|
| `--format`      | `string` | `table` | Format the output. Values: [table \| json]. |
| `-q`, `--quiet` |          |         | Only display IDs                            |


<!---MARKER_GEN_END-->


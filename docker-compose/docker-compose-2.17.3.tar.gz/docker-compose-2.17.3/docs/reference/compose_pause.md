# docker compose pause

<!---MARKER_GEN_START-->
Pause services


<!---MARKER_GEN_END-->

## Description

Pauses running containers of a service. They can be unpaused with `docker compose unpause`.
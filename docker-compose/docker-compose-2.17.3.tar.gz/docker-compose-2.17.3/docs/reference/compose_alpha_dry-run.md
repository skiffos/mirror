# docker compose alpha dry-run

<!---MARKER_GEN_START-->
EXPERIMENTAL - Dry run command allow you to test a command without applying changes


<!---MARKER_GEN_END-->


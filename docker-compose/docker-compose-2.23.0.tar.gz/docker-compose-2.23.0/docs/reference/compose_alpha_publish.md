# docker compose alpha publish

<!---MARKER_GEN_START-->
Publish compose application

### Options

| Name        | Type | Default | Description                     |
|:------------|:-----|:--------|:--------------------------------|
| `--dry-run` |      |         | Execute command in dry run mode |


<!---MARKER_GEN_END-->


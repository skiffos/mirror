# docker compose wait

<!---MARKER_GEN_START-->
Block until the first service container stops

### Options

| Name             | Type | Default | Description                                  |
|:-----------------|:-----|:--------|:---------------------------------------------|
| `--down-project` |      |         | Drops project when the first container stops |
| `--dry-run`      |      |         | Execute command in dry run mode              |


<!---MARKER_GEN_END-->


# docker compose start

<!---MARKER_GEN_START-->
Start services


<!---MARKER_GEN_END-->

## Description

Starts existing containers for a service.

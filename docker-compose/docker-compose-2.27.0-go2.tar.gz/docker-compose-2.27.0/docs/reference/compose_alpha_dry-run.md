# docker compose alpha dry-run

<!---MARKER_GEN_START-->
Dry run command allows you to test a command without applying changes


<!---MARKER_GEN_END-->


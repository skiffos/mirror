# docker compose scale

<!---MARKER_GEN_START-->
Scale services 

### Options

| Name        | Type | Default | Description                     |
|:------------|:-----|:--------|:--------------------------------|
| `--dry-run` |      |         | Execute command in dry run mode |
| `--no-deps` |      |         | Don't start linked services     |


<!---MARKER_GEN_END-->


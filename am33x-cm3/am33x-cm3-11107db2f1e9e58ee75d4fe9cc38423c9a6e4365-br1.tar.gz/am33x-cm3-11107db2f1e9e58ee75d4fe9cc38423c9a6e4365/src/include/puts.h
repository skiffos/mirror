#ifndef _PUTS_H_
#define _PUTS_H_

#include <types.h>

int putchar(int c);
int puts(const char *str);
int putsn(const char *s, size_t maxlen);

#endif

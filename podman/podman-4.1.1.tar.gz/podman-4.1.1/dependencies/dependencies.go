//go:build !linter
// +build !linter

package dependencies

import (
	_ "github.com/onsi/ginkgo/ginkgo"
)

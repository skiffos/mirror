// +build windows no_devmapper

package main

func main() {
}

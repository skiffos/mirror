## The libocispec Project Community Code of Conduct

The libocispec project follows the [Containers Community Code of Conduct](https://github.com/containers/common/blob/master/CODE-OF-CONDUCT.md).
